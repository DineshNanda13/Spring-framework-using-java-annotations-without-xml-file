package cricket_Leagues;

public interface Fixtures {
	
	public String getFixtures();

}
