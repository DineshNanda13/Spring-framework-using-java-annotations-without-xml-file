package cricket_Leagues;

public interface Leagues {
	
	public String getLeagueName();
	
	public String getLeagueFixtures();
}
